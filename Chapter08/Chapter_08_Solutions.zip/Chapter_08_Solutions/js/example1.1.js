//execute script when window is loaded
window.onload = function(){

    var container = d3.select("body"); //get the <body> element from the DOM

    console.log(container);

};