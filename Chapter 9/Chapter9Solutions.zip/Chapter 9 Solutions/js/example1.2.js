//execute script when window is loaded
window.onload = function(){

    var container = d3.select("body")
    					.append("svg"); //get the <body> element from the DOM

    console.log(container);



};