//initialize function called when the script loads
function initialize(){
	loadData();
	debugAjax();
};

function loadData(){

var cities;

$.getJSON("data/MegaCities.geojson", function(geojsonData){
	cities = geojsonData;
	console.log(cities);
});
}

function debugCallback(mydata){
	
	$("#mydiv").append('GeoJSON data: ' + JSON.stringify(mydata));
};

function debugAjax(){

	$.ajax("data/MegaCities.geojson", {
		dataType: "json",
		success: function(response){
			debugCallback(response);
		}
	});
};

//call the initialize function when the document has loaded
$(document).ready(initialize);